//
//  data.swift
//  coredataexample
//
//  Created by Elluminati Mac Mini 1 on 05/04/18.
//  Copyright © 2018 Example. All rights reserved.
//

import UIKit
import CoreData
class data: NSManagedObject {

}
