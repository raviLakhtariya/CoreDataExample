//
//  StudentDetails+CoreDataClass.swift
//  coredataexample
//
//  Created by Elluminati Mac Mini 1 on 05/04/18.
//  Copyright © 2018 Example. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData


public class StudentDetails: NSManagedObject {

}
